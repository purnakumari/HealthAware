const http = require("http"), fs = require("fs"), path = require("path"), zlib = require("zlib"), crypto = require("crypto");
const PORT = process.env.PORT || 3000, ROOT = __dirname, DATA = path.join(ROOT, "data");
const FB_TO = "diethealthawareness@gmail.com";
fs.mkdirSync(DATA, { recursive: true });
const TYPES = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "text/javascript; charset=utf-8",
  ".json": "application/json", ".svg": "image/svg+xml", ".png": "image/png" };

const rd = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(DATA, f))); } catch { return d; } };
const wr = (f, v) => fs.writeFileSync(path.join(DATA, f), JSON.stringify(v, null, 1));
const hash = (p, s) => crypto.scryptSync(p, s, 32).toString("hex");
const eq = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
const OK = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const sessions = {}, resets = {};

/* Email: set SMTP_PASS (Gmail App Password) and run "npm install". Otherwise emails are printed in this terminal. */
let mailer = null;
if (process.env.SMTP_PASS) {
  try { mailer = require("nodemailer").createTransport({ service: "gmail",
    auth: { user: process.env.SMTP_USER || FB_TO, pass: process.env.SMTP_PASS } }); }
  catch { console.log("Run 'npm install' to enable email sending."); }
}
async function mail(to, subject, text, replyTo) {
  if (!mailer) { console.log(`\n[EMAIL NOT CONFIGURED]\nTo: ${to}\nSubject: ${subject}\n${text}\n`); return false; }
  try { await mailer.sendMail({ from: `HealthAware <${process.env.SMTP_USER || FB_TO}>`, to, subject, text, replyTo }); return true; }
  catch (e) { console.log("Mail error:", e.message); return false; }
}

async function api(req, res, p, b) {
  const send = (c, o) => { res.writeHead(c, { "Content-Type": "application/json" }); res.end(JSON.stringify(o)); };
  const tok = (req.headers.authorization || "").slice(7), me = sessions[tok];
  const users = rd("users.json", {}), email = String(b.email || "").trim().toLowerCase(), pw = String(b.password || "");
  const start = e => { const t = crypto.randomBytes(24).toString("hex"); sessions[t] = e; return t; };
  const setPw = (e, name) => { const salt = crypto.randomBytes(16).toString("hex");
    users[e] = { name: name || users[e].name, salt, hash: hash(pw, salt) }; wr("users.json", users); };

  if (p === "me") return me && users[me] ? send(200, { email: me, name: users[me].name }) : send(401, { error: "auth" });
  if (p === "logout") { delete sessions[tok]; return send(200, {}); }
  if (p === "register") {
    if (!OK.test(email) || pw.length < 6) return send(400, { error: "invalid" });
    if (users[email]) return send(409, { error: "exists" });
    setPw(email, String(b.name || "").slice(0, 60) || email.split("@")[0]);
    return send(200, { token: start(email), email, name: users[email].name });
  }
  if (p === "login") {
    const u = users[email];
    if (!u || !eq(hash(pw, u.salt), u.hash)) return send(401, { error: "bad" });
    return send(200, { token: start(email), email, name: u.name });
  }
  if (p === "forgot") {
    if (users[email]) {
      const code = String(crypto.randomInt(100000, 1000000));
      resets[email] = { code, exp: Date.now() + 15 * 60000, tries: 0 };
      await mail(email, "HealthAware password reset code", `Your reset code is ${code}. It expires in 15 minutes. If you did not request this, ignore this email.`);
    }
    return send(200, {});
  }
  if (p === "reset") {
    const r = resets[email];
    if (!users[email] || !r || r.exp < Date.now() || r.tries++ >= 5 || !eq(r.code, String(b.code || "").trim()) || pw.length < 6)
      return send(400, { error: "invalid" });
    setPw(email); delete resets[email];
    return send(200, {});
  }
  if (p === "feedback") {
    const message = String(b.message || "").slice(0, 2000);
    if (!message.trim()) return send(400, { error: "empty" });
    const fb = { date: new Date().toISOString(), name: String(b.name || "").slice(0, 60), email: String(b.email || "").slice(0, 80),
      rating: +b.rating || 0, message, account: me || "guest" };
    const all = rd("feedback.json", []); all.push(fb); wr("feedback.json", all);
    const emailed = await mail(FB_TO, `HealthAware feedback (${fb.rating}/5)`,
      `From: ${fb.name} <${fb.email}>\nAccount: ${fb.account}\n\n${message}`, OK.test(fb.email) ? fb.email : undefined);
    return send(200, { emailed });
  }
  send(404, { error: "nf" });
}

http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split("?")[0]);
  if (url.startsWith("/api/")) {
    let s = "";
    req.on("data", c => { s += c; if (s.length > 1e4) req.destroy(); });
    req.on("end", () => {
      let b = {}; try { b = JSON.parse(s || "{}"); } catch {}
      api(req, res, url.slice(5), b).catch(() => { res.writeHead(500); res.end("{}"); });
    });
    return;
  }
  const file = path.join(ROOT, url === "/" ? "index.html" : path.normalize(url));
  if (!file.startsWith(ROOT) || file.startsWith(DATA) || /server\.js$|node_modules/.test(file)) { res.writeHead(404); return res.end("Not found"); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const type = TYPES[path.extname(file)] || "application/octet-stream";
    const h = { "Content-Type": type, "X-Content-Type-Options": "nosniff",
      "Cache-Control": /html|sw\.js/.test(file) ? "no-cache" : "public, max-age=3600" };
    if (/gzip/.test(req.headers["accept-encoding"] || "") && /text|javascript|json|svg/.test(type)) {
      h["Content-Encoding"] = "gzip"; data = zlib.gzipSync(data);
    }
    res.writeHead(200, h); res.end(data);
  });
}).listen(PORT, () => console.log(`HealthAware running at http://localhost:${PORT}${mailer ? "  (email ON)" : "  (email OFF - codes print here)"}`));

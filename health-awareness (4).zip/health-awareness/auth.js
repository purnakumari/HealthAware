async function api(p, body, method = "POST") {
  const r = await fetch("/api/" + p, { method,
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + (localStorage.token || "") },
    body: method === "GET" ? undefined : JSON.stringify(body || {}) }).catch(() => { throw new Error("noserver"); });
  if (!(r.headers.get("content-type") || "").includes("json")) throw new Error("noserver");
  const d = await r.json();
  if (!r.ok) throw new Error(d.error || "err");
  return d;
}

let mode = "login";
const msg = k => ($("aMsg").textContent = T(k));
function setMode(m) {
  mode = m;
  document.querySelectorAll("#auth [data-m]").forEach(e => (e.hidden = !e.dataset.m.split(" ").includes(m)));
  document.querySelectorAll("#auth [data-go]").forEach(e => (e.hidden = e.dataset.go === m));
  $("aGo").textContent = T({ login: "login", register: "register", forgot: "sendCode", reset: "resetBtn" }[m]);
  $("aMsg").textContent = "";
}
document.querySelectorAll("[data-go]").forEach(b => (b.onclick = () => setMode(b.dataset.go)));
const _x = window.extra;
window.extra = () => { _x(); setMode(mode); };

$("aForm").onsubmit = async e => {
  e.preventDefault();
  const b = { name: $("fName").value, email: $("fEmail").value.trim().toLowerCase(), password: $("fPass").value, code: $("fCode").value };
  try {
    if (mode === "forgot") { await api("forgot", b); setMode("reset"); return msg("codeSent"); }
    if (mode === "reset") { await api("reset", b); setMode("login"); return msg("resetDone"); }
    const d = await api(mode, b);
    localStorage.removeItem("guest");
    localStorage.token = d.token; localStorage.user = d.email; localStorage.name = d.name;
    location.reload();
  } catch (x) { msg(x.message === "noserver" ? "noServer" : "err"); }
};
$("guestBtn").onclick = () => { localStorage.guest = "1"; location.reload(); };
$("logoutBtn").onclick = async () => {
  try { await api("logout"); } catch {}
  ["token", "user", "name", "guest"].forEach(k => localStorage.removeItem(k));
  location.reload();
};

function enter(name) {
  $("auth").hidden = true; $("logoutBtn").hidden = false;
  $("who").textContent = "👤 " + name;
  $("fbName").value = localStorage.guest ? "" : name; $("fbEmail").value = localStorage.user || "";
}
(async () => {
  if (localStorage.token) {
    try { const d = await api("me", null, "GET"); localStorage.name = d.name; return enter(d.name); }
    catch (x) {
      if (x.message === "noserver") return enter(localStorage.name || "");
      ["token", "user", "name"].forEach(k => localStorage.removeItem(k));
    }
  }
  if (localStorage.guest === "1") return enter("Guest");
  $("auth").hidden = false;
})();

$("fbForm").onsubmit = async e => {
  e.preventDefault();
  const b = { name: $("fbName").value, email: $("fbEmail").value, rating: $("fbRate").value, message: $("fbText").value };
  try {
    const d = await api("feedback", b);
    if (!d.emailed) throw new Error("mail");
    $("fbOut").textContent = T("fbThanks"); e.target.reset();
  } catch {
    location.href = "mailto:diethealthawareness@gmail.com?subject=" + encodeURIComponent(`HealthAware feedback (${b.rating}/5)`) +
      "&body=" + encodeURIComponent(`${b.message}\n\n${b.name} <${b.email}>`);
    $("fbOut").textContent = T("fbMail");
  }
};

let dip;
addEventListener("beforeinstallprompt", e => { e.preventDefault(); dip = e; $("inst").hidden = false; });
$("inst").onclick = () => dip && dip.prompt();

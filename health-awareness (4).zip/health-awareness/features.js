const NUMS = ["108", "104", "112", "102"];
const VOICE = { en: "en-IN", te: "te-IN", hi: "hi-IN" };

function water() {
  const k = K("water-" + new Date().toISOString().slice(0, 10)), n = +localStorage.getItem(k) || 0, goal = 8;
  $("waterBox").innerHTML =
    `<div class="wrow"><button data-d="-1" aria-label="-1">−</button><b>${n}/${goal}</b><button data-d="1" aria-label="+1">+</button></div>` +
    `<p>💧 ${T("glass")}${n >= goal ? " – " + T("goalMet") : ""}</p>` +
    `<div class="track"><div style="height:100%;width:${Math.min(100, (n / goal) * 100)}%;background:#0ea5e9"></div></div>`;
  $("waterBox").querySelectorAll("button").forEach(b => (b.onclick = () => {
    localStorage.setItem(k, Math.max(0, n + +b.dataset.d)); water();
  }));
  calcScore();
}

function emergency() {
  $("emerList").innerHTML = T("emer").map((l, i) =>
    `<a class="rem sos" href="tel:${NUMS[i]}"><h4>📞 ${NUMS[i]}</h4><p>${l}</p></a>`).join("");
  $("schTxt").textContent = T("sch");
}

function speakButtons() {
  document.querySelectorAll(".card").forEach(c => {
    if (c.querySelector(".spk")) return;
    const b = document.createElement("button");
    b.className = "spk ghost"; b.textContent = "🔊";
    b.onclick = () => {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(c.innerText.replace("🔊", ""));
      u.lang = VOICE[L]; speechSynthesis.speak(u);
    };
    c.prepend(b);
  });
  document.querySelectorAll(".spk").forEach(b => b.setAttribute("aria-label", T("read")));
}

window.extra = () => { water(); emergency(); mealPlan(); dailyTip(); calcScore(); if ("speechSynthesis" in window) speakButtons(); };

["bmiW", "bmiH"].forEach(i => ($(i).oninput = bmi));
["nW", "nAge"].forEach(i => ($(i).oninput = nutrients));
document.documentElement.classList.toggle("big", localStorage.big === "1");
$("big").onclick = () => localStorage.big = document.documentElement.classList.toggle("big") ? "1" : "0";
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});

const td = () => new Date().toISOString().slice(0, 10);
let was = 0;
function confetti() {
  for (let i = 0; i < 40; i++) {
    const s = document.createElement("span");
    s.className = "cf"; s.textContent = ["🎉", "✨", "💚", "🍎", "💧"][i % 5];
    s.style.cssText = `left:${Math.random() * 100}vw;animation-delay:${Math.random()}s`;
    document.body.append(s); setTimeout(() => s.remove(), 3500);
  }
}
function calcScore() {
  const n = +localStorage.getItem(K("water-" + td())) || 0;
  const c = [...document.querySelectorAll(".hc")], hy = c.filter(x => x.checked).length / (c.length || 1);
  const w = +$("bmiW").value, h = +$("bmiH").value / 100, b = w && h ? w / (h * h) : 0;
  const s = Math.round(Math.min(1, n / 8) * 40 + hy * 40 + (b ? (b >= 18.5 && b < 25 ? 20 : 10) : 0));
  $("score").textContent = s;
  $("ring").style.cssText = `--p:${s};--c:${s >= 80 ? "#22c55e" : s >= 50 ? "#fde047" : "#ef4444"}`;
  if (s === 100 && was < 100) confetti();
  was = s;
}
function dailyTip() {
  const t = T("dtips");
  $("dtip").textContent = "💡 " + t[Math.floor(Date.now() / 864e5) % t.length];
}
function mealPlan() {
  const g = $("goal").value || 1;
  $("goal").innerHTML = T("goals").map((x, i) => `<option value="${i}">${x}</option>`).join("");
  $("goal").value = g;
  $("plan").textContent = T("plans")[g];
}
$("goal").onchange = mealPlan;
document.addEventListener("input", calcScore);
document.addEventListener("change", calcScore);
$("wa").onclick = () => open("https://wa.me/?text=" + encodeURIComponent(`${T("shareTxt")} ${$("score").textContent}/100 ${location.href}`));
$("pr").onclick = () => print();
const root = document.documentElement;
root.classList.toggle("dark", (localStorage.theme || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")) === "dark");
$("theme").onclick = () => localStorage.theme = root.classList.toggle("dark") ? "dark" : "light";
extra();

function setData(d) { localStorage.setItem(K("survey"), JSON.stringify(d)); dashboard(); }
$("demoOn").onclick = () => {
  const v = ["Anakapalle", "Chodavaram", "Sankaram", "Narsipatnam", "Yelamanchili"], d = getData().filter(x => !x.demo);
  for (let i = 0; i < 20; i++)
    d.push({ name: "Demo " + (i + 1), village: v[i % 5], meals: [2, 3, 3, 3, 4][i % 5], aware: i % 3 ? "yes" : "no", junk: (i * 3) % 8, date: td(), demo: true });
  setData(d);
};
$("demoOff").onclick = () => setData(getData().filter(x => !x.demo));
$("clrBtn").onclick = () => {
  if (!confirm(T("sure"))) return;
  const u = ":" + (localStorage.user || "guest");
  Object.keys(localStorage).filter(k => k.endsWith(u) && /^(survey|water-)/.test(k)).forEach(k => localStorage.removeItem(k));
  document.querySelectorAll("input[type=number],#remQ").forEach(i => (i.value = ""));
  document.querySelectorAll(".hc").forEach(c => (c.checked = false));
  $("nChart").innerHTML = ""; $("bmiOut").textContent = "";
  hygiene(); nutrients(); remedies(); dashboard(); extra();
};

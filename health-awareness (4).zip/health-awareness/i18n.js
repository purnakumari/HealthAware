const I18N = {
  en: {
    brand: "HealthAware", tag: "Community Health Awareness Platform – Nutrition & Traditional Health-Care",
    nBmi: "BMI", nNut: "Nutrients", nHyg: "Hygiene", nRem: "Remedies", nSur: "Survey", nDash: "Dashboard",
    bmiT: "BMI Calculator", wt: "Weight (kg)", ht: "Height (cm)", calc: "Calculate",
    cat: ["Underweight", "Normal", "Overweight", "Obese"],
    nutT: "Daily Nutrient Targets", age: "Age group",
    ages: ["Child (5-12)", "Teen (13-19)", "Adult (20-59)", "Senior (60+)"],
    prot: "Protein", carb: "Carbohydrates", fat: "Fats", wat: "Water (litres)",
    hygT: "Household Hygiene Audit",
    hyg: ["Boiled/filtered drinking water", "Handwashing before meals", "Waste segregation", "Clean kitchen & storage", "Proper ventilation"],
    score: "Hygiene score",
    remT: "Traditional Remedies", search: "Search remedies...",
    warn: "For awareness only. Not a substitute for a doctor's advice.",
    rem: [["Turmeric milk", "Soothes cough and helps minor wounds heal."],
      ["Ginger tea", "Helps with cold and indigestion."],
      ["Tulsi decoction", "Supports immunity."],
      ["Millets (ragi, jowar)", "Provide energy, iron and calcium."],
      ["Yoga & pranayama", "Reduce stress and improve breathing."]],
    surT: "Community Survey", name: "Name", village: "Village", meals: "Meals per day",
    diet: "Aware of balanced diet?", yes: "Yes", no: "No", junk: "Junk food per week (times)",
    submit: "Save response", saved: "Saved!",
    dashT: "Survey Dashboard", total: "Responses", csv: "Export CSV", clear: "Clear data",
    chart1: "Diet awareness", chart2: "Meals per day"
  },
  te: {
    brand: "హెల్త్‌అవేర్", tag: "సామాజిక ఆరోగ్య అవగాహన వేదిక – పోషణ & సంప్రదాయ ఆరోగ్య పద్ధతులు",
    nBmi: "BMI", nNut: "పోషకాలు", nHyg: "పరిశుభ్రత", nRem: "ఇంటి చిట్కాలు", nSur: "సర్వే", nDash: "డాష్‌బోర్డ్",
    bmiT: "BMI కాలిక్యులేటర్", wt: "బరువు (కిలోలు)", ht: "ఎత్తు (సెం.మీ)", calc: "లెక్కించు",
    cat: ["తక్కువ బరువు", "సాధారణం", "అధిక బరువు", "ఊబకాయం"],
    nutT: "రోజువారీ పోషక లక్ష్యాలు", age: "వయసు వర్గం",
    ages: ["పిల్లలు (5-12)", "టీనేజ్ (13-19)", "పెద్దలు (20-59)", "వృద్ధులు (60+)"],
    prot: "ప్రోటీన్", carb: "కార్బోహైడ్రేట్లు", fat: "కొవ్వులు", wat: "నీరు (లీటర్లు)",
    hygT: "ఇంటి పరిశుభ్రత తనిఖీ",
    hyg: ["మరిగించిన/వడకట్టిన తాగునీరు", "భోజనానికి ముందు చేతులు కడగడం", "చెత్తను వేరు చేయడం", "శుభ్రమైన వంటగది & నిల్వ", "సరైన గాలి, వెలుతురు"],
    score: "పరిశుభ్రత స్కోరు",
    remT: "సంప్రదాయ చిట్కాలు", search: "వెతకండి...",
    warn: "అవగాహన కోసమే. వైద్యుని సలహాకు ప్రత్యామ్నాయం కాదు.",
    rem: [["పసుపు పాలు", "దగ్గుకు, చిన్న గాయాలకు ఉపశమనం ఇస్తుంది."],
      ["అల్లం టీ", "జలుబు, అజీర్ణానికి సహాయపడుతుంది."],
      ["తులసి కషాయం", "రోగనిరోధక శక్తిని పెంచుతుంది."],
      ["చిరుధాన్యాలు (రాగులు, జొన్నలు)", "శక్తి, ఇనుము, కాల్షియం అందిస్తాయి."],
      ["యోగా & ప్రాణాయామం", "ఒత్తిడి తగ్గించి శ్వాసను మెరుగుపరుస్తాయి."]],
    surT: "సామాజిక సర్వే", name: "పేరు", village: "గ్రామం", meals: "రోజుకు భోజనాలు",
    diet: "సమతుల్య ఆహారంపై అవగాహన ఉందా?", yes: "అవును", no: "కాదు", junk: "వారానికి జంక్ ఫుడ్ (సార్లు)",
    submit: "సేవ్ చేయి", saved: "సేవ్ అయింది!",
    dashT: "సర్వే డాష్‌బోర్డ్", total: "స్పందనలు", csv: "CSV ఎగుమతి", clear: "డేటా తొలగించు",
    chart1: "ఆహార అవగాహన", chart2: "రోజుకు భోజనాలు"
  },
  hi: {
    brand: "हेल्थअवेयर", tag: "सामुदायिक स्वास्थ्य जागरूकता मंच – पोषण और पारंपरिक स्वास्थ्य पद्धतियाँ",
    nBmi: "BMI", nNut: "पोषक तत्व", nHyg: "स्वच्छता", nRem: "घरेलू नुस्खे", nSur: "सर्वे", nDash: "डैशबोर्ड",
    bmiT: "BMI कैलकुलेटर", wt: "वजन (किग्रा)", ht: "ऊँचाई (सेमी)", calc: "गणना करें",
    cat: ["कम वजन", "सामान्य", "अधिक वजन", "मोटापा"],
    nutT: "दैनिक पोषण लक्ष्य", age: "आयु वर्ग",
    ages: ["बच्चे (5-12)", "किशोर (13-19)", "वयस्क (20-59)", "वरिष्ठ (60+)"],
    prot: "प्रोटीन", carb: "कार्बोहाइड्रेट", fat: "वसा", wat: "पानी (लीटर)",
    hygT: "घरेलू स्वच्छता जाँच",
    hyg: ["उबला/छना पेयजल", "भोजन से पहले हाथ धोना", "कचरा अलग करना", "साफ रसोई व भंडारण", "उचित हवा-रोशनी"],
    score: "स्वच्छता स्कोर",
    remT: "पारंपरिक नुस्खे", search: "खोजें...",
    warn: "केवल जागरूकता हेतु। डॉक्टर की सलाह का विकल्प नहीं।",
    rem: [["हल्दी वाला दूध", "खाँसी और छोटे घावों में आराम देता है।"],
      ["अदरक की चाय", "सर्दी और अपच में मदद करती है।"],
      ["तुलसी का काढ़ा", "रोग प्रतिरोधक क्षमता बढ़ाता है।"],
      ["मोटे अनाज (रागी, ज्वार)", "ऊर्जा, आयरन और कैल्शियम देते हैं।"],
      ["योग और प्राणायाम", "तनाव घटाते और श्वसन सुधारते हैं।"]],
    surT: "सामुदायिक सर्वे", name: "नाम", village: "गाँव", meals: "प्रतिदिन भोजन",
    diet: "क्या संतुलित आहार की जानकारी है?", yes: "हाँ", no: "नहीं", junk: "सप्ताह में जंक फूड (बार)",
    submit: "सहेजें", saved: "सहेजा गया!",
    dashT: "सर्वे डैशबोर्ड", total: "प्रतिक्रियाएँ", csv: "CSV निर्यात", clear: "डेटा हटाएँ",
    chart1: "आहार जागरूकता", chart2: "प्रतिदिन भोजन"
  }
};

Object.assign(I18N.en, {
  nEmer: "Emergency", watT: "Water Tracker", glass: "glasses today", goalMet: "Goal reached!", read: "Read aloud",
  tips: ["Add protein, milk, eggs/pulses, nuts and healthy snacks.", "Great! Keep up a balanced diet and daily activity.", "Walk 30 minutes daily; cut sugar and fried food.", "Consult a doctor for a diet and exercise plan."],
  bmiNote: "For adults 18+. Children need age-based growth charts.",
  emerT: "Emergency & Government Help", emer: ["Ambulance", "Health helpline", "Emergency", "Mother & child"],
  sch: "Eligible families can get free treatment under Ayushman Bharat / state health schemes. Ask the hospital help desk. Call 104 for health advice."
});
Object.assign(I18N.te, {
  nEmer: "అత్యవసరం", watT: "నీటి ట్రాకర్", glass: "గ్లాసులు నేడు", goalMet: "లక్ష్యం పూర్తి!", read: "చదివి వినిపించు",
  tips: ["ప్రోటీన్, పాలు, గుడ్లు/పప్పులు, గింజలు తీసుకోండి.", "చాలా బాగుంది! సమతుల్య ఆహారం, రోజువారీ వ్యాయామం కొనసాగించండి.", "రోజూ 30 నిమిషాలు నడవండి; చక్కెర, వేపుళ్లు తగ్గించండి.", "ఆహార, వ్యాయామ ప్రణాళిక కోసం వైద్యుని సంప్రదించండి."],
  bmiNote: "18+ పెద్దలకు మాత్రమే. పిల్లలకు వయసు ఆధారిత గ్రోత్ చార్టులు అవసరం.",
  emerT: "అత్యవసర & ప్రభుత్వ సహాయం", emer: ["అంబులెన్స్", "ఆరోగ్య హెల్ప్‌లైన్", "అత్యవసర సేవలు", "తల్లి & శిశు సేవలు"],
  sch: "అర్హులైన కుటుంబాలకు ఆయుష్మాన్ భారత్ / రాష్ట్ర ఆరోగ్య పథకాల కింద ఉచిత చికిత్స లభిస్తుంది. ఆసుపత్రి హెల్ప్ డెస్క్‌ను అడగండి. ఆరోగ్య సలహా కోసం 104 కు కాల్ చేయండి."
});
Object.assign(I18N.hi, {
  nEmer: "आपात", watT: "पानी ट्रैकर", glass: "गिलास आज", goalMet: "लक्ष्य पूरा!", read: "पढ़कर सुनाएँ",
  tips: ["प्रोटीन, दूध, अंडे/दालें, मेवे लें।", "बहुत अच्छा! संतुलित आहार और रोज़ व्यायाम जारी रखें।", "रोज़ 30 मिनट चलें; चीनी और तला खाना घटाएँ।", "आहार व व्यायाम योजना हेतु डॉक्टर से मिलें।"],
  bmiNote: "केवल 18+ वयस्कों के लिए। बच्चों हेतु आयु-आधारित ग्रोथ चार्ट चाहिए।",
  emerT: "आपातकालीन व सरकारी सहायता", emer: ["एम्बुलेंस", "स्वास्थ्य हेल्पलाइन", "आपातकालीन सेवा", "माँ व शिशु"],
  sch: "पात्र परिवारों को आयुष्मान भारत / राज्य स्वास्थ्य योजनाओं में मुफ़्त इलाज मिल सकता है। अस्पताल हेल्प डेस्क से पूछें। स्वास्थ्य सलाह हेतु 104 पर कॉल करें।"
});

Object.assign(I18N.en, {
  scoreT: "Your Health Score today", share: "Share on WhatsApp", shareTxt: "My health score on HealthAware:", print: "Print",
  dtips: ["Drink a glass of water first thing in the morning.", "Add one green leafy vegetable to today's meals.", "Walk for 30 minutes – it's free medicine.", "Wash hands with soap before every meal.", "Replace one fried snack with fruit or sprouts."],
  dietT: "Daily Meal Planner", goalL: "My goal", goals: ["Gain weight", "Stay healthy", "Lose weight"],
  plans: ["🌅 Breakfast: ragi dosa/idli with peanut chutney + banana milk. 🍛 Lunch: rice, dal, egg/paneer curry, greens, curd. 🌙 Dinner: chapati, vegetable kurma, boiled egg or sprouts. 🥜 Snack: groundnut-jaggery chikki, fruit.",
    "🌅 Breakfast: idli/upma + sambar + fruit. 🍛 Lunch: rice, dal, 2 vegetables, curd. 🌙 Dinner: chapati/millet roti, dal, salad. 🍎 Snack: fruit or sprouts.",
    "🌅 Breakfast: vegetable oats/ragi malt + 1 boiled egg or sprouts. 🍛 Lunch: 1 cup rice, big salad, dal, greens. 🌙 Dinner: light – vegetable soup, 1-2 rotis. 🥕 Snack: cucumber, buttermilk."]
});
Object.assign(I18N.te, {
  scoreT: "ఈ రోజు మీ ఆరోగ్య స్కోరు", share: "వాట్సాప్‌లో షేర్ చేయండి", shareTxt: "హెల్త్‌అవేర్‌లో నా ఆరోగ్య స్కోరు:", print: "ప్రింట్",
  dtips: ["ఉదయాన్నే ఒక గ్లాసు నీరు తాగండి.", "ఈ రోజు భోజనంలో ఒక ఆకుకూర చేర్చండి.", "30 నిమిషాలు నడవండి – ఇది ఉచిత మందు.", "ప్రతి భోజనానికి ముందు సబ్బుతో చేతులు కడగండి.", "ఒక వేపుడు స్నాక్ బదులు పండు లేదా మొలకలు తీసుకోండి."],
  dietT: "రోజువారీ భోజన ప్రణాళిక", goalL: "నా లక్ష్యం", goals: ["బరువు పెరగడం", "ఆరోగ్యంగా ఉండటం", "బరువు తగ్గడం"],
  plans: ["🌅 ఉదయం: రాగి దోశ/ఇడ్లీ + వేరుశనగ చట్నీ + అరటి పాలు. 🍛 మధ్యాహ్నం: అన్నం, పప్పు, గుడ్డు/పనీర్ కూర, ఆకుకూర, పెరుగు. 🌙 రాత్రి: చపాతీ, కూరగాయల కుర్మా, ఉడికించిన గుడ్డు లేదా మొలకలు. 🥜 స్నాక్: పల్లీ-బెల్లం చిక్కీ, పండు.",
    "🌅 ఉదయం: ఇడ్లీ/ఉప్మా + సాంబార్ + పండు. 🍛 మధ్యాహ్నం: అన్నం, పప్పు, రెండు కూరలు, పెరుగు. 🌙 రాత్రి: చపాతీ/చిరుధాన్యాల రొట్టె, పప్పు, సలాడ్. 🍎 స్నాక్: పండు లేదా మొలకలు.",
    "🌅 ఉదయం: కూరగాయల ఓట్స్/రాగి జావ + ఉడికించిన గుడ్డు లేదా మొలకలు. 🍛 మధ్యాహ్నం: ఒక కప్పు అన్నం, పెద్ద సలాడ్, పప్పు, ఆకుకూర. 🌙 రాత్రి: తేలికగా – కూరగాయల సూప్, 1-2 రొట్టెలు. 🥕 స్నాక్: దోసకాయ, మజ్జిగ."]
});
Object.assign(I18N.hi, {
  scoreT: "आज का आपका स्वास्थ्य स्कोर", share: "व्हाट्सऐप पर शेयर करें", shareTxt: "हेल्थअवेयर पर मेरा स्वास्थ्य स्कोर:", print: "प्रिंट",
  dtips: ["सुबह सबसे पहले एक गिलास पानी पिएँ।", "आज के भोजन में एक हरी पत्तेदार सब्ज़ी जोड़ें।", "30 मिनट चलें – यह मुफ़्त दवा है।", "हर भोजन से पहले साबुन से हाथ धोएँ।", "एक तले स्नैक की जगह फल या अंकुरित अनाज खाएँ।"],
  dietT: "दैनिक भोजन योजना", goalL: "मेरा लक्ष्य", goals: ["वजन बढ़ाना", "स्वस्थ रहना", "वजन घटाना"],
  plans: ["🌅 नाश्ता: रागी डोसा/इडली + मूंगफली चटनी + केला दूध। 🍛 दोपहर: चावल, दाल, अंडा/पनीर सब्ज़ी, साग, दही। 🌙 रात: चपाती, सब्ज़ी कुर्मा, उबला अंडा या अंकुरित अनाज। 🥜 स्नैक: मूंगफली-गुड़ चिक्की, फल।",
    "🌅 नाश्ता: इडली/उपमा + सांभर + फल। 🍛 दोपहर: चावल, दाल, दो सब्ज़ियाँ, दही। 🌙 रात: चपाती/मिलेट रोटी, दाल, सलाद। 🍎 स्नैक: फल या अंकुरित अनाज।",
    "🌅 नाश्ता: सब्ज़ी ओट्स/रागी माल्ट + उबला अंडा या अंकुरित अनाज। 🍛 दोपहर: एक कटोरी चावल, बड़ा सलाद, दाल, साग। 🌙 रात: हल्का – सब्ज़ी सूप, 1-2 रोटी। 🥕 स्नैक: खीरा, छाछ।"]
});

Object.assign(I18N.en, {
  login: "Login", register: "Register", logout: "Logout", email: "Email", pass: "Password", code: "Reset code",
  forgot: "Forgot password?", sendCode: "Send reset code", resetBtn: "Reset password", guest: "Continue as guest",
  codeSent: "If this email is registered, a reset code was sent. Enter it with your new password.",
  resetDone: "Password changed. Please log in.",
  noServer: "Accounts need the Node server (npm start). You can continue as guest.",
  err: "Something went wrong. Check your details and try again.",
  fbT: "Send Feedback", rate: "Rating", fbMsg: "Your feedback", fbSend: "Send",
  fbThanks: "Thank you! Feedback sent.", fbMail: "Your email app opened – press Send to deliver it.",
  demoOn: "Load demo data", demoOff: "Remove demo data", resetAll: "Reset all my data",
  sure: "Delete ALL your saved data on this device?"
});
Object.assign(I18N.te, {
  login: "లాగిన్", register: "నమోదు", logout: "లాగౌట్", email: "ఈమెయిల్", pass: "పాస్‌వర్డ్", code: "రీసెట్ కోడ్",
  forgot: "పాస్‌వర్డ్ మర్చిపోయారా?", sendCode: "రీసెట్ కోడ్ పంపు", resetBtn: "పాస్‌వర్డ్ మార్చు", guest: "అతిథిగా కొనసాగండి",
  codeSent: "ఈ ఈమెయిల్ నమోదై ఉంటే రీసెట్ కోడ్ పంపబడింది. కొత్త పాస్‌వర్డ్‌తో పాటు నమోదు చేయండి.",
  resetDone: "పాస్‌వర్డ్ మార్చబడింది. దయచేసి లాగిన్ అవండి.",
  noServer: "ఖాతాలకు Node సర్వర్ (npm start) అవసరం. మీరు అతిథిగా కొనసాగవచ్చు.",
  err: "ఏదో తప్పు జరిగింది. వివరాలు సరిచూసి మళ్లీ ప్రయత్నించండి.",
  fbT: "అభిప్రాయం పంపండి", rate: "రేటింగ్", fbMsg: "మీ అభిప్రాయం", fbSend: "పంపు",
  fbThanks: "ధన్యవాదాలు! అభిప్రాయం పంపబడింది.", fbMail: "మీ ఈమెయిల్ యాప్ తెరుచుకుంది – పంపడానికి Send నొక్కండి.",
  demoOn: "డెమో డేటా లోడ్ చేయి", demoOff: "డెమో డేటా తొలగించు", resetAll: "నా డేటా మొత్తం రీసెట్ చేయి",
  sure: "ఈ పరికరంలో మీ సేవ్ చేసిన డేటా మొత్తం తొలగించాలా?"
});
Object.assign(I18N.hi, {
  login: "लॉगिन", register: "रजिस्टर", logout: "लॉगआउट", email: "ईमेल", pass: "पासवर्ड", code: "रीसेट कोड",
  forgot: "पासवर्ड भूल गए?", sendCode: "रीसेट कोड भेजें", resetBtn: "पासवर्ड बदलें", guest: "अतिथि के रूप में जारी रखें",
  codeSent: "यदि यह ईमेल पंजीकृत है तो रीसेट कोड भेजा गया है। नए पासवर्ड के साथ दर्ज करें।",
  resetDone: "पासवर्ड बदल गया। कृपया लॉगिन करें।",
  noServer: "खातों के लिए Node सर्वर (npm start) चाहिए। आप अतिथि के रूप में जारी रख सकते हैं।",
  err: "कुछ गलत हुआ। विवरण जाँचकर फिर प्रयास करें।",
  fbT: "फीडबैक भेजें", rate: "रेटिंग", fbMsg: "आपकी प्रतिक्रिया", fbSend: "भेजें",
  fbThanks: "धन्यवाद! फीडबैक भेज दिया गया।", fbMail: "आपका ईमेल ऐप खुल गया – भेजने के लिए Send दबाएँ।",
  demoOn: "डेमो डेटा लोड करें", demoOff: "डेमो डेटा हटाएँ", resetAll: "मेरा सारा डेटा रीसेट करें",
  sure: "इस डिवाइस पर आपका सारा सहेजा डेटा हटाएँ?"
});

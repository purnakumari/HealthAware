const K = k => k + ":" + (localStorage.getItem("user") || "guest");
const dl = (navigator.language || "en").slice(0, 2);
let L = localStorage.getItem("lang") || (I18N[dl] ? dl : "en");
const $ = id => document.getElementById(id);
const T = k => I18N[L][k];

function draw(id, cfg) {
  const d = cfg.data, v = d.datasets[0].data, col = d.datasets[0].backgroundColor, tot = v.reduce((x, y) => x + y, 0);
  let svg, leg = "";
  if (cfg.type === "doughnut") {
    const r = 40, C = 2 * Math.PI * r;
    let off = 0;
    svg = `<svg viewBox="0 0 100 100" role="img"><circle cx="50" cy="50" r="${r}" fill="none" stroke="#9993" stroke-width="16"/><g transform="rotate(-90 50 50)">` +
      v.map((x, i) => { const l = tot ? (x / tot) * C : 0;
        const s = `<circle cx="50" cy="50" r="${r}" fill="none" stroke-width="16" stroke="${col[i]}" stroke-dasharray="${l} ${C - l}" stroke-dashoffset="${-off}"/>`;
        off += l; return s; }).join("") + "</g></svg>";
    leg = '<p class="leg">' + d.labels.map((l, i) => `<span><i style="background:${col[i]}"></i>${l} ${v[i]}</span>`).join("") + "</p>";
  } else {
    const mx = Math.max(1, ...v), w = 100 / v.length;
    svg = '<svg viewBox="0 0 100 60" role="img">' + v.map((x, i) => { const h = (x / mx) * 40;
      return `<rect x="${i * w + w * 0.15}" y="${48 - h}" width="${w * 0.7}" height="${h}" fill="${col}"/>` +
        `<text x="${i * w + w / 2}" y="58" font-size="5" text-anchor="middle" fill="currentColor">${d.labels[i]}</text>` +
        `<text x="${i * w + w / 2}" y="${46 - h}" font-size="5" text-anchor="middle" fill="currentColor">${x}</text>`; }).join("") + "</svg>";
  }
  $(id).innerHTML = svg + leg;
}

/* ---------- Language ---------- */
function setLang(l) {
  const age = $("nAge").value || 2;
  const checks = [...document.querySelectorAll(".hc")].map(c => c.checked);
  L = l;
  localStorage.setItem("lang", l);
  document.documentElement.lang = l;
  document.querySelectorAll("[data-i18n]").forEach(e => (e.textContent = T(e.dataset.i18n)));
  $("remQ").placeholder = T("search");
  $("nAge").innerHTML = T("ages").map((a, i) => `<option value="${i}">${a}</option>`).join("");
  $("nAge").value = age;
  $("hygList").innerHTML = T("hyg").map(h => `<label><input type="checkbox" class="hc"> ${h}</label>`).join("");
  document.querySelectorAll(".hc").forEach((c, i) => {
    c.checked = !!checks[i];
    c.onchange = hygiene;
  });
  bmi(); nutrients(); hygiene(); remedies(); dashboard();
  if (window.extra) extra();
}

/* ---------- BMI ---------- */
function bmi() {
  const w = +$("bmiW").value, h = +$("bmiH").value / 100;
  if (!w || !h) { $("bmiOut").textContent = ""; return; }
  const b = w / (h * h), i = b < 18.5 ? 0 : b < 25 ? 1 : b < 30 ? 2 : 3;
  $("bmiOut").innerHTML = `<b>${b.toFixed(1)}</b> – <span class="pill c${i}">${T("cat")[i]}</span><p>${T("tips")[i]}</p><small>${(18.5*h*h).toFixed(0)}–${(24.9*h*h).toFixed(0)} kg · ${T("bmiNote")}</small>`;
}

/* ---------- Nutrient targets ---------- */
function nutrients() {
  const w = +$("nW").value, a = +$("nAge").value;
  if (!w) { $("nOut").textContent = ""; return; }
  const kcal = w * [70, 45, 35, 30][a];
  const p = w * [1, 0.95, 1.1, 1][a];
  const c = (kcal * 0.55) / 4, f = (kcal * 0.25) / 9, water = w * 0.035;
  $("nOut").innerHTML =
    `<p>🔥 ${Math.round(kcal)} kcal</p><p>${T("prot")}: <b>${p.toFixed(0)} g</b></p>` +
    `<p>${T("carb")}: <b>${c.toFixed(0)} g</b></p><p>${T("fat")}: <b>${f.toFixed(0)} g</b></p>` +
    `<p>${T("wat")}: <b>${water.toFixed(1)}</b></p>`;
  draw("nChart", {
    type: "doughnut",
    data: { labels: [T("prot"), T("carb"), T("fat")],
      datasets: [{ data: [p, c, f].map(Math.round), backgroundColor: ["#f59e0b", "#10b981", "#ef4444"] }] }
  });
}

/* ---------- Hygiene ---------- */
function hygiene() {
  const c = [...document.querySelectorAll(".hc")];
  const p = Math.round((c.filter(x => x.checked).length / c.length) * 100);
  $("hygBar").style.width = p + "%";
  $("hygBar").style.background = p >= 80 ? "#10b981" : p >= 50 ? "#f59e0b" : "#ef4444";
  $("hygOut").textContent = `${T("score")}: ${p}%`;
}

/* ---------- Remedies ---------- */
function remedies() {
  const q = $("remQ").value.toLowerCase();
  $("remList").innerHTML = T("rem")
    .filter(r => (r[0] + r[1]).toLowerCase().includes(q))
    .map(r => `<div class="rem"><h4>🌿 ${r[0]}</h4><p>${r[1]}</p></div>`).join("");
}

/* ---------- Survey + dashboard ---------- */
const getData = () => JSON.parse(localStorage.getItem(K("survey")) || "[]");

function dashboard() {
  const d = getData();
  $("dTotal").textContent = d.length;
  const yes = d.filter(x => x.aware === "yes").length;
  draw("cAware", { type: "doughnut",
    data: { labels: [T("yes"), T("no")], datasets: [{ data: [yes, d.length - yes], backgroundColor: ["#10b981", "#ef4444"] }] } });
  const m = {};
  d.forEach(x => (m[x.meals] = (m[x.meals] || 0) + 1));
  draw("cMeals", { type: "bar",
    data: { labels: Object.keys(m), datasets: [{ label: T("chart2"), data: Object.values(m), backgroundColor: "#0d9488" }] } });
}

$("sForm").onsubmit = e => {
  e.preventDefault();
  const d = getData();
  d.push({ name: $("sName").value, village: $("sVillage").value, meals: +$("sMeals").value,
    aware: $("sAware").value, junk: +$("sJunk").value, date: new Date().toISOString().slice(0, 10) });
  localStorage.setItem(K("survey"), JSON.stringify(d));
  e.target.reset();
  $("sMsg").textContent = T("saved");
  setTimeout(() => ($("sMsg").textContent = ""), 2000);
  dashboard();
};

$("csvBtn").onclick = () => {
  const d = getData();
  if (!d.length) return;
  const rows = [Object.keys(d[0]).join(",")].concat(d.map(r => Object.values(r).map(v => `"${v}"`).join(",")));
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\ufeff" + rows.join("\n")], { type: "text/csv" }));
  a.download = "survey.csv";
  a.click();
};

$("clrBtn").onclick = () => { localStorage.removeItem(K("survey")); dashboard(); };

/* ---------- Wire up ---------- */
$("bmiBtn").onclick = bmi;
$("nBtn").onclick = nutrients;
$("remQ").oninput = remedies;
$("lang").onchange = e => setLang(e.target.value);
$("lang").value = L;
setLang(L);
